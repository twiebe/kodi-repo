# Nightcity design rules

Rules every view follows. Tests in `tests/static` hold them where they can be checked.

## Navigation

The remote moves through levels, not through confirmations.

- **Up and Left go one level up, Down and Right one level down.** Up on the top row of a page
  leaves it (Back). Left on a settings page goes back to its categories, Right enters them.
- **No dead ends.** Every control a remote can reach has a way back to where the window started.
- **Back returns where you left.** Back (or Up at the top) from a page opened by OK lands on the
  element that opened it: the same item, the same tab. A TMDb chain reopens the page before as a
  new page, so the click keeps the way back (`info_leave`, `info_back`, `osd_back` in
  `scripts/nightcity.py`); a chain from the player's cast row ends on that row, on that person.
  Info pages have no way-back button: Up from the button row is the way, and the hint in the
  middle of the path line names where it leads (↑ previous page, ↑ video, ↑ movies). Only a row
  that would be empty otherwise (a person without a biography, the page of the title that plays
  without a description) keeps one, so something takes the focus; it names the page before
  ("‹ The Matrix"), on the chain's first page and over the playing video where the chain
  started.
- **Back held goes back to where the browsing started**, past every page of a chain: to the
  page the chain started from, on the element that started it, or to the player's controls on
  their first button (play or resume) when the chain started from the player's cast row.
  In the player's chapter panel and cast row it goes to those controls too, on their first
  button.
  Outside a chain, and on its first page, it is a Back.

### Key hints

Where a key leads to another level and the screen does not show it, a quiet line says so: the
key, then the level it leads to (`LevelHint` in `Includes_Base.xml`,
`tests/static/test_level_hints.py`).

- **Keys are glyphs, OK is OK:** ↑ ↓ ← → for the directions, ↑↓ and ←→ for a move along a
  list or row, and for OK the word OK, as on the remote's key, in the same dimmed blue as the
  arrows (every font of both skins has it; the return arrow read as Enter, a keyboard's key).
  No other key words ("Left", "Up/Down"). The Back key gets no hint: it always goes back, and
  every hinted level has an arrow back. Should one ever be needed it is the word Back, not a
  glyph.
- **The label names where the key leads**, not what it does: ↓ cast, ← system,
  OK controls. The player's OSD bar is "controls" everywhere (OK from the seek bar, ↑ from the
  cast row, ↓ from a panel); "menu" is a column or row of buttons beside a list (the
  library's, Home's top menu). Where the level depends on how the screen was opened, the
  hint names it from there (`HintInfoBack`, `HintWindowBack` in `Variables.xml`: the page of
  Home, the library, the video, the page before in a TMDb chain), "back" only where nothing
  tells. Where Left is Kodi's Back through folders (the add-on browser's list, the file
  manager's left pane) it names the folder above as "parent folder", for Kodi does not name it,
  and the window before at the top of the folders (`HintAddonsBack`, `HintFilesBack`). A footer
  of keys acting on the spot (skin settings slots: OK choose, → option,
  ↑↓ move, OK drop; the console: OK open) names the action.
- **Look:** the key in the dimmed blue of a hint (`state_text`), the label muted
  (`text_mute`), small caps (`font_caps_small`, `LookLabelCase`), a shadow over video.
- **Per page, stable:** a hint belongs to the page, not to the focused element. Each edge's hint
  says where its key leads from the page's outermost element towards that edge: ← what Left
  does on the leftmost column or list, ↑ what Up does on the top row, ↓ what Down does on the
  bottom row. It shows wherever the focus is on the page and does not change when the focus
  moves. Where that key does nothing on the outermost element, the edge has no hint (the
  library's grid, the lists of the video and music windows, the categories of add-on
  settings). The label may follow the page's own state (the folder the add-on browser or file
  manager is in), never the focus. The player's levels are pages of their own: the seek bar
  over the bare video, the controls (also while a panel above a button is open, the chapter
  panel too), the cast row. A hint fades out and the next one in after it, never on top of it; a
  window's hint hides under a dialog, and like the pages it does not fade over a playing video.
- **Exceptions, open for now:** the → of a settings page with categories (shown while they have
  the focus, see below); the footer of the episodes on an info page (←→ episode,
  ↑ season, ↓ cast, OK select) shows the keys of the focused row while it has the focus; the
  skin settings' slot footer (OK choose, → option; ↑↓ move, OK drop) shows on the slot rows,
  for its keys act on the slot. The player's footer adds OK all settings while subtitles, audio
  or video has the focus (↓ cast & crew   OK all settings). The console's footer (OK open) does
  not depend on the focus. Home's footer names, while the focus is in the top line, where Down
  leads into the shown page (↓ spotlight, ↓ rows where the spotlight is off, ↓ search for a
  title, ↓ quick menu from its icon) and on the movies, shows and music tabs OK all movies,
  all shows or all albums, on the quick menu's icon OK settings: the tabs act on the page below
  them.
- **Hints that follow the focus stand right of the standing ones**, in footers and headers
  alike: what holds on the whole page first, the shortcut of the focused element after it.
- **Where a hint stands follows its key**, nothing else:
  - ↑ at the top: centred on the path line of a page (top 30, the title kept left of the
    middle, `pathwidth` 780), on the player's top edge (top 140), on the top edge of the quick
    menu's panel;
  - ← up the screen's left edge, written bottom to top and centred on it (`LevelHintLeft`). The
    line is turned a quarter to the left, so it runs along the edge and its key, an ↑ in the
    text, shows as ←. In a dialog (an overlay over a window) ← and → belong to the dialog: they
    stand inside its frame, along its inner edges, centred on them (24 in), the dialog wider by
    their room and its content in by as much, so they never stand on the list nor outside the
    frame over the window below (the select dialogs, the add-on settings);
  - ↓ and OK in the footer line at the bottom, centred (top 1030), as ↑ is centred at the top; in
    the player too. The episodes' footer (an exception above) may hold several directions:
    ←→ episode, ↑ season, ↓ cast, OK select;
  - → down the screen's right edge, written top to bottom and centred on it (`LevelHintRight`,
    `LevelHintLeft` mirrored, its ↑ turned to →), in a dialog inside its frame as ←. It names the way into the
    next column: from the categories of a settings page into their settings (→ settings), on
    the settings rail and in the skin's select dialogs a list of choices taking the focused one
    (→ select; not a multi-select, where Right stays). Where it leads out of one column of
    several (the settings' categories) it shows while the focus is in that column, as the
    hints that follow the focus do. The alternative tried for dialogs: ← and → at the screen's
    edges, as on a page;
  - the footers of a settings page (the console's, the skin settings' slots) stay under their
    description.
- No hint where the level is in sight anyway: Home's top menu over the rows (Up), the queue under
  the music OSD, the tabs over their lists.

### The position bar of the library grid

All movies and all shows have a faint rail at the far right with a mark of where the grid stands.
Right goes grid, menu, bar, Left comes back the same way. On the bar the mark becomes a cursor that
names its group, whatever the sort: a letter, a year, a month, a whole rating or a half hour of runtime (1:30). Up and Down move one
group, evenly over the rail whatever the sizes of the groups, and the grid follows at once (focus
applies). OK goes to the group's first title, Left stays there too, Back returns to the card it came
from. With fewer than three groups there is no bar: Right stays on the menu.

The cursor glides from group to group. The column beside it (menu, title and plot) keeps its left
edge and the same distance to the cards and to the rail; while the bar has the focus its right edge
comes in as far as the widest label needs.

The music library has the same bar in both views, on the lists of albums, artists and genres sorted by
title, artist, album, genre or year. Other sorts have no groups to name, and nobody jumps through a
list of songs, so no bar there. The parent
folder and "all albums" belong to no group. Esc and the like stay what they were off the bar: they
leave the window.

### The skin's select dialogs

The filter dialogs (the library grid's and the music library's) and the details dialog of the list
have one OK and no Cancel: Left goes one level up and keeps what is ticked (in a group it confirms,
on the list of groups it closes), Right one level down (on the list of groups it opens the group,
in a multi-select it stays), Back cancels. Every select dialog, Kodi's own too: Up from the
buttons goes back to the list.

### Selectors are skipped from above

A selector is a row that chooses what the content below it shows: season tabs above the
episodes, cast and crew above the credits, movies and shows on a person page, the categories
of a page.

- Down from the element above a selector lands on the content, past the selector.
- Up from the content lands on the selector, up again on the element above.
- The selector is never the place the focus falls into by itself.

Example: on an episode, Play, Down: the episodes. Up: the season tabs. Up: Play.

### Focus applies, OK goes

- **Moving onto an element that changes the current view applies it at once.** A tab, a
  season, cast or crew, movies or shows: the cursor on it is the choice, no OK needed.
- **An element that leaves the view needs OK.** Opening an info page, playing, opening the
  episodes of a show from the spotlight, opening a dialog or another window.

Rule of thumb: if the screen around the focus stays and only its content changes, focus applies
it. If the screen changes, OK does.

The spotlight of Home follows it too (home, movies, shows and music pages): the cursor on a title card of a row (movie, show, episode, season) shows that title in the
hero with what the spotlight shows of a title, whatever kind the spotlight holds. An episode has
its show and SxxEyy in the kicker and the poster of its show. The rotation stands meanwhile, and
the pills, chevrons and progress line are hidden: they act on the spotlight's own title. Up from
the top row still goes to the buttons. The hero is the spotlight again as soon as the cursor is
anywhere else: on its buttons, in the top menu, on a card that is no title (a genre tab). The same
title stands there and its interval starts anew.

The Music page's album spotlight does the same on an album or an artist card, with what it shows of
an album as far as the card has it; a genre leaves it alone. All of it from the library, no online
lookups, and no ratings since that spotlight has none. Its buttons are out of sight meanwhile.

Home, movies and shows each have their own spotlight, with its source and change interval. A page
whose spotlight is off has no hero: its rows start at the top, Down from the menu goes into them, Up
from the first row back to the menu. A spotlight whose interval is "still" keeps its hero and its
buttons (play, info, all movies or all shows), but shows the title Down would land on instead of one
of its own: the current title of the row that had the cursor last, before any the first row with
titles. The buttons act on that title (play plays a movie or an episode, a show opens its next
episode, anything else its page), Left and Right only move between them, Down lands on exactly that
title, Up from the rows comes back to the buttons. Moving along the menu to such a page shows its
title at once; on a title card the hero follows the card as above.

Both swaps fade 400 ms, as long as the spotlight's own crossfade of poster, logo and backdrop. Onto
a card the spotlight fades out under the card's hero fading in. Off a card the card's hero goes at
once (it shows whatever has the focus, there is nothing left to fade out) and the spotlight fades
in, text and pills with it. Between two cards it is a title change as in the spotlight: text at
once, poster and backdrop crossfade.

The combo row (continue watching + next up) holds what was started, then next up. Where next up
starts, a thin rule in the gap before its first card and the words next up under that card, in the
dimmed blue of a separator; the cursor passes it like any gap. A show whose episode was started stands
in the first part with that episode and not again in next up (both would open the same episode).

Ratings are on everywhere by default: the spotlight has them wherever the cursor is, also in the top
menu while it rotates. "Ratings only on title pages" (off by default) saves the requests: spotlight
and rows then show none and fetch none, a title's page shows them as ever.

The online ratings of the card come once the cursor stood still on it for 1.5 s (the service points
TMDb Helper at the row, 2 s at worst until the request goes out): moving along a row costs no
request, coming back to a card none either. Until they are there the line shows nothing, never the
ratings of another title. Cards without a library id (Trending) get them too.

Each page of the top menu can be hidden in the skin settings, home too, but never the last one
shown: its switch is locked. Without the home page the first page shown takes its place
wherever Home opens without a page: after startup, on the Home key, and right from the icon
next to the clock wrapping round.

The quick menu on Home follows it too: the cursor on the icon next to the clock shows the menu,
Down goes into it, OK opens the settings page (Back held there returns like Back on the icon),
Up from its top comes out onto the icon with the menu still shown, Left or Right off the icon
hide it. Back, in the menu or on the icon, closes it: the focus goes back
to where it came onto the icon from (a settings row, a row of a page, the top menu), or to the
shown page's own entry. The keys that open the quick menu (Home held, the S key, Kodi's power
menu) go to the icon on every page of Home, which shows the menu; the same key again closes it
like Back. Only over other windows (an info page, the player)
the quick menu is a dialog.

A choice that loads a TMDb list waits while another TMDb list loads (`TmdbBusy`,
`nc_credits_tab`): two plugin lists at once crash Kodi. The cursor still decides, the list
follows a moment later.

Not applied on focus, on purpose:

- **Toggles and cycles** (sort field and direction, posters or list in the library, "more" in the
  OSD): on focus they would flip on every pass.
- **Recent search terms**: each one runs a new search and moves to the front of the list, so
  the terms would reorder under the cursor. OK runs it.

### Exceptions, for now

Kodi's own windows keep Kodi's way until it is settled how they should behave: the settings
(Settings, setting categories, skin settings, add-on settings), the file manager and the add-on
browser.

## What the colours say

| Colour | Role | Examples |
|---|---|---|
| White (`text`, graded `text_dim`/`text_mute`) | content, what you read | titles, plot, values, clock, tags, rating stars and labels |
| Cyan (`accent`) | the cursor, where you are | focus fill and line, latent cursor (next episode title), Play pill, mouse pointer |
| Dimmed blue (`state`/`state_text`) | state and hints, quiet | active tab, selected value, counters 3/25, separators, progress background, scroll chevron |
| Pink (`accent2`) | order and identity: names or numbers something, never changes with input | the kicker line over titles, dialog headings, the numbering in the settings (rail numbers), of the rows on the pages of Home and on the system page (tile numbers), the heading of a notification |
| Yellow (`accent3`/`warn`) | warnings only | notifications that warn about something |

- Pink never shows state or cursor; that is the dimmed blue. At most one pink element per area.
- Row numbers count the rows that are shown on a page of Home (home, movies, shows, music):
  01, 02, ... without gaps, a hidden row (empty slot, nothing in it) takes no number. The
  spotlight is 00 and has no heading, so the first row is 01 also on a page without spotlight;
  the numbers are about rows. Each row is its own area for the one-pink rule.
- Yellow only for warnings: the heading of a warning or error notification. `accent3` is not
  used. The skin tells such a notification by Kodi's icon for it (`media/DefaultIconWarning.png`,
  `DefaultIconError.png`, drawn by `tools/make_textures.py`); every other one has a pink
  heading, like the progress toasts. The text under the heading is `text_dim`, and the skin's
  type icons (info, warning, error) are a hint in
  `state_text`. An add-on's own icon keeps its colours.
- The keys in a hint line (OK open, ← system) are hints: dimmed blue, the label after them
  muted (Key hints above).
- `state` is border_dim made opaque over the page, so a thin line looks the same on any
  background; text and small marks take `state_text`, the same hue just light enough to read
  (4.5:1).
- Cyan also marks a few things that are where you go or act: the primary button (Play), the
  search field's outline, the quick menu's icon while the focus is in that menu (Up and Back
  lead there), slider nibs, the fill of a progress bar, the head of the seek line and the
  playing time, and the dog-ear of an unwatched title. The seek line's chapter marks are the
  colour of its track (`border_dim`).
- Every card has the cut corners, the netrunner shape, focused or not. An unfocused card has a
  faint frame in `border_dim`; the focus brings the bright cyan frame and the glow.
- The cursor glows: a soft cyan halo around the focused card, button, pill, row or tile. Kodi
  draws a control only inside its own rect, so a glowing button is 10 px larger on each side
  than it looks (padded textures, `tests/static/test_glow.py`).
- A button Kodi disables (the add-on dialog's Configure, Uninstall, Dependencies where the add-on
  has none) greys its label out to `text_mute`; the focus skips it. A button that can be chosen
  never shows in `text_mute`, so the two tell apart at a glance (`PillButton`, `LookPillDisabled`).
- A pill's text gets its case from its font (`font_caps_pill`, capitals in Nightcity, each word
  capitalised in Confuse), so a label Kodi sets at run time matches the skin's own.
- The static test `tests/static/test_colors.py` holds the skin to this table.
- **A progress line says where you are** in something that plays or was watched: under an
  episode or a card. It stays on its item when the cursor moves away. The music queue has none:
  Kodi redraws a list item only while the cursor is on it, so a live line elsewhere stood still.
  Its playing track has a dark blue mark instead, wherever the cursor is: the bar of a current
  value before a track's number, a line a little above a card's cover. The current episode in
  the list of an episode page is marked by its title alone, in the accent colour.
