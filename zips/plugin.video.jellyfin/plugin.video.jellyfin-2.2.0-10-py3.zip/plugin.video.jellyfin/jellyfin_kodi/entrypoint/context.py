# -*- coding: utf-8 -*-

#################################################################################################

import json
import sys

import xbmc
import xbmcaddon
import xbmcvfs

from .. import database
from ..dialogs import context
from ..helper import translate, settings, dialog, LazyLogger
from ..helper.deletion import delete_item
from ..helper.exceptions import HTTPException
from ..jellyfin import Jellyfin

#################################################################################################

LOG = LazyLogger(__name__)
XML_PATH = (
    xbmcaddon.Addon("plugin.video.jellyfin").getAddonInfo("path"),
    "default",
    "1080i",
)
OPTIONS = {
    "Refresh": translate(30410),
    "Delete": translate(30409),
    "Addon": translate(30408),
    "AddFav": translate(30405),
    "RemoveFav": translate(30406),
    "Transcode": translate(30412),
    "AddPlaylist": translate(30413),
}
# Items that can go into a playlist on their own
PLAYLIST_TYPES = ("Movie", "Episode", "MusicVideo", "Video", "Audio")

#################################################################################################


class Context(object):

    _selected_option = None

    def __init__(self, transcode=False, delete=False):

        try:
            self.kodi_id = sys.listitem.getVideoInfoTag().getDbId() or None
            self.media = self.get_media_type()
            self.server_id = sys.listitem.getProperty("jellyfinserver") or None
            self.api_client = Jellyfin(self.server_id).get_client().jellyfin
            item_id = sys.listitem.getProperty("jellyfinid")
        except AttributeError:
            self.server_id = None

            if xbmc.getInfoLabel("ListItem.Property(jellyfinid)"):
                item_id = xbmc.getInfoLabel("ListItem.Property(jellyfinid)")
            else:
                self.kodi_id = xbmc.getInfoLabel("ListItem.DBID")
                self.media = xbmc.getInfoLabel("ListItem.DBTYPE")
                item_id = None

        addon_data = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.jellyfin/data.json"
        )
        with open(addon_data, "rb") as infile:
            data = json.load(infile)

        try:
            server_data = data["Servers"][0]
            self.api_client.config.data["auth.server"] = server_data.get("address")
            self.api_client.config.data["auth.server-name"] = server_data.get("Name")
            self.api_client.config.data["auth.user_id"] = server_data.get("UserId")
            self.api_client.config.data["auth.token"] = server_data.get("AccessToken")
        except Exception as e:
            LOG.warning("Addon appears to not be configured yet: {}".format(e))

        if self.server_id or item_id:
            self.item = self.api_client.get_item(item_id)
        else:
            self.item = self.get_item_id()

        if self.item:

            if transcode:
                self.transcode()

            elif delete:
                self.delete_item()

            elif self.select_menu():
                self.action_menu()

                if self._selected_option in (
                    OPTIONS["Delete"],
                    OPTIONS["AddFav"],
                    OPTIONS["RemoveFav"],
                ):

                    xbmc.sleep(500)
                    xbmc.executebuiltin("Container.Refresh")

    def get_media_type(self):
        """Get media type based on sys.listitem. If unfilled, base on visible window."""
        media = sys.listitem.getVideoInfoTag().getMediaType()

        if not media:

            if xbmc.getCondVisibility("Container.Content(albums)"):
                media = "album"
            elif xbmc.getCondVisibility("Container.Content(artists)"):
                media = "artist"
            elif xbmc.getCondVisibility("Container.Content(songs)"):
                media = "song"
            elif xbmc.getCondVisibility("Container.Content(pictures)"):
                media = "picture"
            else:
                LOG.info("media is unknown")

        return media

    def get_item_id(self):
        """Get synced item from jellyfindb."""
        item = database.get_item(self.kodi_id, self.media)

        if not item:
            return

        try:
            user_data = json.loads(item[4]) if item[4] else {}
        except ValueError:
            # Not the user data, e.g. written by an older version
            user_data = {}

        return {
            "Id": item[0],
            "UserData": user_data if isinstance(user_data, dict) else {},
            "Type": item[3],
        }

    def select_menu(self):
        """Display the select dialog.
        Favorites, Refresh, Delete (opt), Settings.
        """
        options = []

        if self.item["Type"] != "Season":

            if self.item["UserData"].get("IsFavorite"):
                options.append(OPTIONS["RemoveFav"])
            else:
                options.append(OPTIONS["AddFav"])

        if self.item["Type"] in PLAYLIST_TYPES:
            options.append(OPTIONS["AddPlaylist"])

        options.append(OPTIONS["Refresh"])

        if settings("enableContextDelete.bool"):
            options.append(OPTIONS["Delete"])

        options.append(OPTIONS["Addon"])

        context_menu = context.ContextMenu("script-jellyfin-context.xml", *XML_PATH)
        context_menu.set_options(options)
        context_menu.doModal()

        if context_menu.is_selected():
            self._selected_option = context_menu.get_selected()

        return self._selected_option

    def action_menu(self):

        selected = self._selected_option

        if selected == OPTIONS["Refresh"]:
            self.api_client.refresh_item(self.item["Id"])

        elif selected == OPTIONS["AddFav"]:
            self.api_client.favorite(self.item["Id"], True)

        elif selected == OPTIONS["RemoveFav"]:
            self.api_client.favorite(self.item["Id"], False)

        elif selected == OPTIONS["Addon"]:
            xbmc.executebuiltin("Addon.OpenSettings(plugin.video.jellyfin)")

        elif selected == OPTIONS["Delete"]:
            self.delete_item()

        elif selected == OPTIONS["AddPlaylist"]:
            self.add_to_playlists()

    def add_to_playlists(self):
        """Add the item to the playlists the user picks.
        Playlists that hold it already are skipped, the server would add it twice.
        """
        media_type = "Audio" if self.item["Type"] == "Audio" else "Video"
        playlists = [
            playlist
            for playlist in (self.api_client.get_playlists() or {}).get("Items", [])
            # Empty playlists have no media type yet, older servers send none
            if playlist.get("MediaType") in (None, "Unknown", media_type)
        ]

        if not playlists:
            dialog("ok", "{jellyfin}", translate(30415))
            return

        selected = dialog(
            "multi", translate(30414), [playlist["Name"] for playlist in playlists]
        )
        if not selected:
            return

        added, present, failed = [], [], []
        for index in selected:
            playlist = playlists[index]
            try:
                if self.api_client.is_in_playlist(playlist["Id"], self.item["Id"]):
                    present.append(playlist["Name"])
                else:
                    self.api_client.add_to_playlist(playlist["Id"], self.item["Id"])
                    added.append(playlist["Name"])
            except HTTPException as error:
                LOG.warning(
                    "Adding %s to playlist %s failed: %s",
                    self.item["Id"],
                    playlist["Id"],
                    error.status,
                )
                failed.append(playlist["Name"])

        messages = [
            translate(string_id).format(", ".join(names))
            for string_id, names in ((30416, added), (30417, present), (30418, failed))
            if names
        ]
        dialog(
            "notification",
            heading="{jellyfin}",
            message="\n".join(messages),
            icon="{jellyfin}",
            sound=False,
        )

    def delete_item(self):
        if settings("skipContextMenu.bool") or dialog(
            "yesno", "{jellyfin}", translate(33015)
        ):
            delete_item(self.api_client, self.item["Id"], server_id=self.server_id)

    def transcode(self):
        filename = xbmc.getInfoLabel("ListItem.Filenameandpath")
        filename += "&transcode=true"
        xbmc.executebuiltin("PlayMedia(%s)" % filename)
