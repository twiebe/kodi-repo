# -*- coding: utf-8 -*-

#################################################################################################

import json
import threading

import xbmc

from ..helper import LazyLogger, settings

# If numpy is installed, the websockets library tries to use it, and then
# kodi hard crashes for reasons I don't even want to pretend to understand
import sys  # noqa: E402,I100

sys.modules["numpy"] = None
import websocket  # noqa: E402,I201

##################################################################################################

LOG = LazyLogger(__name__)

##################################################################################################


class WSClient(threading.Thread):

    wsc = None
    stop = False
    # An attempt to connect is under way, on_open ends it
    connecting = False
    token = None

    def __init__(self, client):

        LOG.debug("WSClient initializing...")

        self.client = client
        threading.Thread.__init__(self)
        self.keepalive = None
        self.stopped = threading.Event()
        self.lock = threading.Lock()

    def send(self, message, data=""):

        if self.wsc is None:
            raise ValueError("The websocket client is not started.")

        self.wsc.send(json.dumps({"MessageType": message, "Data": data}))

    def run(self):

        monitor = xbmc.Monitor()
        server = self.client.config.data["auth.server"]
        server = (
            server.replace("https://", "wss://")
            if server.startswith("https")
            else server.replace("http://", "ws://")
        )
        wsc_url = "%s/socket" % server

        LOG.info("Websocket url: %s", wsc_url)

        self.wsc = websocket.WebSocketApp(
            wsc_url,
            header=self.get_headers,
            on_open=lambda ws: self.on_open(ws),
            on_message=lambda ws, message: self.on_message(ws, message),
            on_error=lambda ws, error: self.on_error(ws, error),
        )

        while not self.stop:

            self.wsc.run_forever(ping_interval=10, reconnect=10)

            if not self.stop and monitor.waitForAbort(5):
                break

    def get_headers(self):
        """Called by the websocket library before every connection attempt,
        so a reconnect uses a renewed token."""
        if self.connecting:
            # The last attempt failed before the connection opened, maybe
            # because the server deleted the token (it does that when the
            # user is disabled). Renew it with a saved password.
            self.client.auth.check_token(self.token)
        self.connecting = True
        self.token = self.client.config.data.get("auth.token")

        # Build authorization header for websocket connection
        auth_params = {}
        if "app.device_name" in self.client.config.data:
            auth_params.update(
                {
                    "Client": self.client.config.data["app.name"],
                    "Device": self.client.config.data["app.device_name"],
                    "DeviceId": self.client.config.data["app.device_id"],
                    "Version": self.client.config.data["app.version"],
                }
            )
        if "auth.token" in self.client.config.data:
            auth_params["Token"] = self.token
        auth_line = ", ".join(f'{k}="{v}"' for k, v in auth_params.items())
        return {"Authorization": f"MediaBrowser {auth_line}"}

    def on_error(self, ws, error):
        LOG.error(error)

    def on_open(self, ws):
        self.connecting = False
        LOG.info("--->[ websocket opened ]")
        # Avoid a timing issue where the capabilities are not correctly registered
        if self.stopped.wait(5):
            return
        if settings("remoteControl.bool"):
            self.client.jellyfin.post_capabilities(
                {
                    "PlayableMediaTypes": "Audio,Video",
                    "SupportsMediaControl": True,
                    "SupportedCommands": (
                        "MoveUp,MoveDown,MoveLeft,MoveRight,Select,"
                        "Back,ToggleContextMenu,ToggleFullscreen,ToggleOsdMenu,"
                        "GoHome,PageUp,NextLetter,GoToSearch,"
                        "GoToSettings,PageDown,PreviousLetter,TakeScreenshot,"
                        "VolumeUp,VolumeDown,ToggleMute,SendString,DisplayMessage,"
                        "SetAudioStreamIndex,SetSubtitleStreamIndex,"
                        "SetRepeatMode,Mute,Unmute,SetVolume,"
                        "Play,Playstate,PlayNext,PlayMediaSource"
                    ),
                }
            )
        else:
            self.client.jellyfin.post_capabilities(
                {"PlayableMediaTypes": "Audio, Video", "SupportsMediaControl": False}
            )
        if self.keepalive is not None:
            self.keepalive.stop()
        # A keepalive started after stop_client would keep Kodi from exiting
        with self.lock:
            if self.stop:
                return
            self.keepalive = KeepAlive(self, ws)
            self.keepalive.start()

    def on_message(self, ws, message):

        message = json.loads(message)
        data = message.get("Data", {})

        if message["MessageType"] in ("RefreshProgress",):
            LOG.debug("Ignoring %s", message)

            return

        if not self.client.config.data["app.default"]:
            data["ServerId"] = self.client.auth.server_id

        self.client.callback(message["MessageType"], data)

    def stop_client(self):

        with self.lock:
            self.stop = True
            self.stopped.set()
            keepalive = self.keepalive

        if keepalive is not None:
            keepalive.stop()

        if self.wsc is not None:
            # close() doesn't always wake up the thread waiting for data, it
            # then sleeps in select() for up to 10 seconds. abort() shuts the
            # socket down, so run_forever returns right away.
            self.wsc.keep_running = False
            sock = self.wsc.sock
            if sock is not None:
                sock.abort()
            # The ping thread of the websocket library waits up to
            # ping_interval for this event, Kodi waits for that thread
            stop_ping = getattr(self.wsc, "stop_ping", None)
            if stop_ping is not None:
                stop_ping.set()
            self.wsc.close()


class KeepAlive(threading.Thread):
    def __init__(self, timeout, ws):
        self.halt = threading.Event()
        self.ws = ws

        threading.Thread.__init__(self)

    def stop(self):
        self.halt.set()
        self.join()

    def run(self):
        while not self.halt.is_set():
            if self.halt.wait(30):
                break

            try:
                self.ws.send(json.dumps({"MessageType": "KeepAlive", "Data": 30}))
            except websocket.WebSocketConnectionClosedException:
                # run_forever reconnects, on_open then starts a new keepalive
                LOG.info("Websocket closed, keepalive ends")
                break
