# -*- coding: utf-8 -*-

import sys

# Python 3.0 to 3.8
if sys.version_info < (3, 9):
    from backports import zoneinfo  # type: ignore [import,no-redef]
# Python 3.9 and onwards
else:
    import zoneinfo

import pytest

from jellyfin_kodi.helper import utils
from jellyfin_kodi.helper.utils import (
    convert_to_date,
    convert_to_local,
    strip_credentials,
    values,
)

item1 = {"foo": 123, "bar": 456, "baz": 789}


@pytest.mark.parametrize(
    "item,keys,expected",
    [
        (item1, ["{foo}", "{baz}"], [123, 789]),
        (item1, ["{foo}", "bar"], [123, "bar"]),
        (item1, ["{foo}", "bar", 321], [123, "bar", 321]),
    ],
)
def test_values(item, keys, expected):
    assert list(values(item, keys)) == expected


@pytest.mark.parametrize(
    "utctime,timezone,expected",
    [
        # Special case for malformed data from the server, see #212
        ("0001-01-01T00:00:00.0000000Z", "UTC", "0001-01-01T00:00:00"),
        ("Hello, error.", "Etc/UTC", "Hello, error."),
        ("2023-09-21T23:54:24", "Etc/UTC", "2023-09-21T23:54:24"),
        # See #725
        ("1957-09-21T00:00:00Z", "Europe/Paris", "1957-09-21T01:00:00"),
        ("1970-01-01T00:00:00", "Etc/UTC", "1970-01-01T00:00:00"),
        ("1969-01-01T00:00:00", "Etc/UTC", "1969-01-01T00:00:00"),
        ("1970-01-01T00:00:00", "Europe/Oslo", "1970-01-01T01:00:00"),
        ("1969-01-01T00:00:00", "Europe/Oslo", "1969-01-01T01:00:00"),
        ("2023-09-21T23:54:24", "Europe/Oslo", "2023-09-22T01:54:24"),
        # End of DST in Europe
        ("2023-10-29T00:00:00", "Europe/Oslo", "2023-10-29T02:00:00"),
        ("2023-10-29T00:59:59", "Europe/Oslo", "2023-10-29T02:59:59"),
        ("2023-10-29T01:00:00", "Europe/Oslo", "2023-10-29T02:00:00"),
        # Start of DST in Europe
        ("2023-03-26T00:59:59", "Europe/Oslo", "2023-03-26T01:59:59"),
        ("2023-03-26T01:00:00", "Europe/Oslo", "2023-03-26T03:00:00"),
        # Norway was in permanent summertime 1940-08-11 -> 1942-11-02
        ("1941-06-24T00:00:00", "Europe/Oslo", "1941-06-24T02:00:00"),
        ("1941-12-24T00:00:00", "Europe/Oslo", "1941-12-24T02:00:00"),
        # Not going to test them all, but you get the point...
        # First one fails on Windows with tzdata==2023.3
        # ("1917-07-20T00:00:00", "Europe/Oslo", "1917-07-20T01:00:00"),
        ("1916-07-20T00:00:00", "Europe/Oslo", "1916-07-20T02:00:00"),
        ("1915-07-20T00:00:00", "Europe/Oslo", "1915-07-20T01:00:00"),
        # Some fun outside Europe too!
        ("2023-03-11T03:30:00", "America/St_Johns", "2023-03-11T00:00:00"),
        ("2023-03-13T02:30:00", "America/St_Johns", "2023-03-13T00:00:00"),
        ("2023-11-04T02:30:00", "America/St_Johns", "2023-11-04T00:00:00"),
        ("2023-11-06T03:30:00", "America/St_Johns", "2023-11-06T00:00:00"),
        ("2023-12-24T00:00:00", "Australia/Eucla", "2023-12-24T08:45:00"),
        ("2023-06-24T00:00:00", "Australia/Eucla", "2023-06-24T08:45:00"),
        ("2023-12-24T00:00:00", "Australia/Broken_Hill", "2023-12-24T10:30:00"),
        ("2023-06-24T00:00:00", "Australia/Broken_Hill", "2023-06-24T09:30:00"),
        ("2023-10-31T00:00:00", "Pacific/Kiritimati", "2023-10-31T14:00:00"),
        ("2023-10-31T00:00:00", "Pacific/Midway", "2023-10-30T13:00:00"),
    ],
)
def test_convert_to_local(utctime, timezone, expected):
    assert convert_to_local(utctime, timezone=zoneinfo.ZoneInfo(timezone)) == expected


@pytest.mark.parametrize(
    "timestamp,expected",
    [
        ("2023-10-31T00:00:00.0000000Z", "2023-10-31"),
        ("2023-10-31T00:00:00-07:00", "2023-10-31"),
        ("18081222 183000+0105", "1808-12-22"),
    ],
)
def test_convert_to_date(timestamp, expected):
    assert convert_to_date(timestamp) == expected


@pytest.mark.parametrize(
    "url,expected",
    [
        ("smb://user:pass@server.test/media", "smb://server.test/media"),
        ("smb://server.test/media", "smb://server.test/media"),
        ("smb://user:pass@192.0.2.1/media", "smb://192.0.2.1/media"),
        ("smb://user@192.0.2.1/media", "smb://192.0.2.1/media"),
        ("nfs://server.test/media", "nfs://server.test/media"),
        ("sftp://user:pass@server.test/media", "sftp://server.test/media"),
        ("file://media/movies", "file://media/movies"),
        ("/media/movies", "/media/movies"),
        ("http://user:pass@server.test/media", "http://server.test/media"),
        ("https://user:pass@server.test/media", "https://server.test/media"),
        ("http://server.test/media", "http://server.test/media"),
        ("https://server.test/media", "https://server.test/media"),
    ],
)
def test_strip_credentials(url, expected):
    assert strip_credentials(url) == expected


class FakeAddon:
    def __init__(self, stored):
        self.stored = stored
        self.saved = []

    def getSetting(self, key):
        return self.stored.get(key, "")

    def setSetting(self, key, value):
        self.stored[key] = value
        self.saved.append(key)


@pytest.fixture
def addon(monkeypatch):
    addon = FakeAddon({"server": "http://jellyfin:8096", "kodiCompanion": "true"})
    monkeypatch.setattr(utils.xbmcaddon, "Addon", lambda *args: addon)
    return addon


# Kodi writes settings.xml on every setSetting
def test_setting_with_the_same_value_is_not_saved(addon):
    utils.settings("server", "http://jellyfin:8096")
    utils.settings("kodiCompanion.bool", True)
    assert addon.saved == []


def test_changed_setting_is_saved(addon):
    utils.settings("server", "http://other:8096")
    utils.settings("kodiCompanion.bool", False)
    utils.settings("LastIncrementalSync", "2026-11-21T22:44:39Z")
    assert addon.saved == ["server", "kodiCompanion", "LastIncrementalSync"]
    assert addon.stored["kodiCompanion"] == "false"
