def select_sort_list(sort_methods, **kwargs):
    from xbmcgui import Dialog
    from tmdbhelper.lib.addon.plugin import executebuiltin, format_folderpath, encode_url, get_localized
    x = Dialog().select(get_localized(32309), [i['name'] for i in sort_methods])
    if x == -1:
        return
    for k, v in sort_methods[x]['params'].items():
        kwargs[k] = v
    executebuiltin(format_folderpath(encode_url(**kwargs)))


def sort_list(**kwargs):
    from tmdbhelper.lib.items.directories.lists_sorting import get_sort_methods
    sort_methods = get_sort_methods(kwargs['info'])
    return select_sort_list(sort_methods, **kwargs)
